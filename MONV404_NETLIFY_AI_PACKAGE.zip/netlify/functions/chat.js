// Netlify Function: keeps GROQ_API_KEY on the server, never in index.html.
exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 503, headers,
      body: JSON.stringify({ error: "لم يتم إعداد مفتاح Groq في إعدادات Netlify بعد." })
    };
  }

  let payload;
  try { payload = JSON.parse(event.body || "{}"); }
  catch { return { statusCode: 400, headers, body: JSON.stringify({ error: "طلب غير صالح." }) }; }

  const message = typeof payload.message === "string" ? payload.message.trim() : "";
  if (!message || message.length > 1200) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "اكتب رسالة من 1 إلى 1200 حرف." }) };
  }

  const history = Array.isArray(payload.history) ? payload.history.slice(-8) : [];
  const safeHistory = history
    .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
    .map(m => ({ role: m.role, content: m.content.slice(0, 1200) }));

  const context = payload.context && typeof payload.context === "object" ? payload.context : {};
  const safeContext = {
    programDay: Number.isFinite(Number(context.programDay)) ? Math.max(1, Math.min(30, Number(context.programDay))) : null,
    baselinePerDay: Number.isFinite(Number(context.baselinePerDay)) ? Math.max(0, Math.min(100, Number(context.baselinePerDay))) : null,
    quitDate: typeof context.quitDate === "string" ? context.quitDate.slice(0, 10) : "",
    mode: typeof context.mode === "string" ? context.mode.slice(0, 20) : "",
    reason: typeof context.reason === "string" ? context.reason.slice(0, 220) : "",
    recentLogs: Array.isArray(context.recentLogs) ? context.recentLogs.slice(-7).map(l => ({
      date: String(l.date || "").slice(0, 10),
      uses: l.uses == null ? null : Math.max(0, Math.min(100, Number(l.uses) || 0)),
      craving: l.craving == null ? null : Math.max(0, Math.min(10, Number(l.craving) || 0)),
      mood: String(l.mood || "").slice(0, 30),
      trigger: String(l.trigger || "").slice(0, 80),
      status: String(l.status || "").slice(0, 20)
    })) : []
  };

  const systemPrompt = `أنت "مدرب MONV 404"، مساعد عربي داعم لمساعدة الأشخاص على الإقلاع عن التمباك والتبغ غير المدخن.
قواعدك:
- تحدث بالعربية الواضحة، ويمكنك استخدام تعبيرات سودانية بسيطة إذا بدأ المستخدم بها.
- كن هادئاً وغير حُكمي. لا تهن المستخدم ولا توبخه عند الانتكاس.
- قدم خطوة أو خطوتين عمليتين واضحتين، لا محاضرات طويلة.
- عند الرغبة الشديدة: اقترح تأجيل القرار 10 دقائق، تغيير المكان، شرب الماء، التنفس الهادئ، إشغال اليدين، والاتصال بشخص داعم.
- لا تصف أي كمية من التمباك بأنها آمنة، ولا تشجع على مواصلة الاستخدام للوصول إلى حد رقمي.
- لا تشخّص الأمراض ولا تصف أدوية أو جرعات. شجع على سؤال طبيب أو صيدلي عن وسائل الإقلاع المعتمدة، خصوصاً عند الاعتماد الشديد أو الأعراض المقلقة.
- إذا ذكر المستخدم ألماً في الصدر أو صعوبة تنفس أو إغماء أو أعراضاً خطيرة، وجّهه إلى رعاية طبية عاجلة.
- إذا عبّر عن نية إيذاء نفسه أو خطر فوري، شجعه على التواصل فوراً مع الطوارئ المحلية وشخص موثوق والبقاء معه.
- لا تدّع أنك طبيب أو أنك تراقب المستخدم خارج هذه المحادثة.
- استخدم ملخص التقدم المرفق فقط للتخصيص، ولا تطلب بيانات تعريفية أو أسراراً.
- اجعل الرد عادةً بين 2 و6 جمل.`;

  const userContext = `ملخص تقدم اختياري من التطبيق (قد يكون فارغاً): ${JSON.stringify(safeContext)}\n\nرسالة المستخدم الحالية: ${message}`;

  try {
    const upstream = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.GROQ_MODEL || "llama-3.3-70b-versatile",
        temperature: 0.55,
        max_tokens: 650,
        messages: [
          { role: "system", content: systemPrompt },
          ...safeHistory,
          { role: "user", content: userContext }
        ]
      })
    });

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("Groq API error:", upstream.status, result?.error?.type || "unknown");
      return {
        statusCode: 502, headers,
        body: JSON.stringify({ error: "خدمة الذكاء الاصطناعي لم تستجب. تحقق من المفتاح أو النموذج أو حدود الاستخدام." })
      };
    }
    const reply = result?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return { statusCode: 502, headers, body: JSON.stringify({ error: "وصل رد فارغ من خدمة الذكاء الاصطناعي." }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify({ reply: reply.trim() }) };
  } catch (error) {
    console.error("MONV function failure:", error?.message || "unknown");
    return { statusCode: 502, headers, body: JSON.stringify({ error: "حدث خطأ في الاتصال بخدمة الذكاء الاصطناعي." }) };
  }
};
